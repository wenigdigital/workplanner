# Workplanner 1.3.9 – Release Notes (apps.nextcloud.com)

## Version
1.3.9

## Changelog (für das App Store Release, englisch)

- Planning entries now show the user's display name instead of the account login, in both the overview and the calendar feed.
- New display option: sort entries by time (default) or by user. In user mode, entries are grouped alphabetically per user and sorted chronologically within each user.
- New user filter in the overview to quickly narrow the team plan down to specific users.
- Time input now validates the range immediately and shows an error for invalid ranges (e.g. 10:00 to 09:00). Focus automatically moves to the next field after entering a time, in both the dialog and the mobile quick entry.
- A location is now required for planning entries; overly long location names are trimmed to 120 characters.
- Calendar feed: labels are now translated (German and English) and the public feed endpoint is rate limited (60 requests/hour per IP).
- Security and maintenance: use PHP attributes instead of legacy docblock annotations for the public calendar feed route; added a database index on the user id for planning entries.

## Kurzfassung (deutsch, optional)

- Planungseinträge zeigen jetzt den Anzeigenamen statt des Konto-Namens (UI + Kalender-Feed)
- Neue Sortierung: „Nach Zeit“ oder „Nach Benutzer“ (alphabetisch gruppiert, chronologisch je Benutzer)
- Neuer Benutzer-Filter in der Übersicht
- Zeitbereich wird sofort validiert (z. B. 10:00–09:00 wird abgewiesen), Auto-Fokus auf das nächste Feld
- Standort ist Pflichtfeld; Namen werden auf 120 Zeichen begrenzt
- Kalender-Feed mehrsprachig und mit Rate-Limit (60 req/h/IP)
- PHP-Attribute statt Legacy-Annotationen; neuer DB-Index auf user_id

## Upload-Hinweise

- **Datei:** `workplanner-1.3.9.zip` (Top-Level-Ordner `workplanner`, ohne `.git`)
- **Ziel 1 (empfohlen):** GitHub Release unter https://github.com/wenigdigital/workplanner/releases
  - Tag: `v1.3.9` (oder `1.3.9` – konsistent mit früheren Tags)
  - Titel: `Workplanner 1.3.9`
  - Zip als Asset anhängen → der App Store zieht das Release automatisch aus dem hinterlegten Repository
- **Ziel 2 (direkt):** https://apps.nextcloud.com/apps/submit → bestehende App „Workplanner“ → neue Version → Zip hochladen
